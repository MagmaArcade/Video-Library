﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Register
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Register))
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TbxFirstName = New System.Windows.Forms.TextBox()
        Me.BtnReturn = New System.Windows.Forms.Button()
        Me.BtnNext = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TbxEmail = New System.Windows.Forms.TextBox()
        Me.TbxPhone = New System.Windows.Forms.TextBox()
        Me.TbxLastName = New System.Windows.Forms.TextBox()
        Me.TbxAdress = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DtpDob = New System.Windows.Forms.DateTimePicker()
        Me.GbxPersonalInformation = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TbxPassword = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TbxUsername = New System.Windows.Forms.TextBox()
        Me.GbxTerms = New System.Windows.Forms.GroupBox()
        Me.CbxAgree = New System.Windows.Forms.CheckBox()
        Me.LstDisplay = New System.Windows.Forms.ListBox()
        Me.BtnBack = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GbxPersonalInformation.SuspendLayout()
        Me.GbxTerms.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(22, 272)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(42, 14)
        Me.Label15.TabIndex = 11
        Me.Label15.Text = "Adress"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(22, 140)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(63, 14)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "First Name"
        '
        'TbxFirstName
        '
        Me.TbxFirstName.Location = New System.Drawing.Point(114, 134)
        Me.TbxFirstName.MaxLength = 20
        Me.TbxFirstName.Name = "TbxFirstName"
        Me.TbxFirstName.Size = New System.Drawing.Size(200, 27)
        Me.TbxFirstName.TabIndex = 3
        '
        'BtnReturn
        '
        Me.BtnReturn.Location = New System.Drawing.Point(56, 410)
        Me.BtnReturn.Name = "BtnReturn"
        Me.BtnReturn.Size = New System.Drawing.Size(91, 23)
        Me.BtnReturn.TabIndex = 8
        Me.BtnReturn.Text = "Return to Login"
        Me.BtnReturn.UseVisualStyleBackColor = True
        '
        'BtnNext
        '
        Me.BtnNext.Location = New System.Drawing.Point(304, 410)
        Me.BtnNext.Name = "BtnNext"
        Me.BtnNext.Size = New System.Drawing.Size(75, 23)
        Me.BtnNext.TabIndex = 9
        Me.BtnNext.Text = "Next"
        Me.BtnNext.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(22, 206)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(35, 14)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "Email"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(22, 239)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(41, 14)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "Phone"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(22, 173)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 14)
        Me.Label12.TabIndex = 21
        Me.Label12.Text = "Last Name"
        '
        'TbxEmail
        '
        Me.TbxEmail.Location = New System.Drawing.Point(114, 200)
        Me.TbxEmail.MaxLength = 40
        Me.TbxEmail.Name = "TbxEmail"
        Me.TbxEmail.Size = New System.Drawing.Size(200, 27)
        Me.TbxEmail.TabIndex = 5
        '
        'TbxPhone
        '
        Me.TbxPhone.Location = New System.Drawing.Point(114, 233)
        Me.TbxPhone.MaxLength = 12
        Me.TbxPhone.Name = "TbxPhone"
        Me.TbxPhone.Size = New System.Drawing.Size(200, 27)
        Me.TbxPhone.TabIndex = 6
        '
        'TbxLastName
        '
        Me.TbxLastName.Location = New System.Drawing.Point(114, 167)
        Me.TbxLastName.MaxLength = 20
        Me.TbxLastName.Name = "TbxLastName"
        Me.TbxLastName.Size = New System.Drawing.Size(200, 27)
        Me.TbxLastName.TabIndex = 4
        '
        'TbxAdress
        '
        Me.TbxAdress.Location = New System.Drawing.Point(114, 266)
        Me.TbxAdress.MaxLength = 20
        Me.TbxAdress.Name = "TbxAdress"
        Me.TbxAdress.Size = New System.Drawing.Size(200, 27)
        Me.TbxAdress.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(22, 299)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 14)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "DOB"
        '
        'DtpDob
        '
        Me.DtpDob.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DtpDob.Location = New System.Drawing.Point(114, 299)
        Me.DtpDob.Name = "DtpDob"
        Me.DtpDob.Size = New System.Drawing.Size(200, 20)
        Me.DtpDob.TabIndex = 8
        '
        'GbxPersonalInformation
        '
        Me.GbxPersonalInformation.Controls.Add(Me.Label3)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxPassword)
        Me.GbxPersonalInformation.Controls.Add(Me.Label2)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxUsername)
        Me.GbxPersonalInformation.Controls.Add(Me.Label11)
        Me.GbxPersonalInformation.Controls.Add(Me.DtpDob)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxFirstName)
        Me.GbxPersonalInformation.Controls.Add(Me.Label1)
        Me.GbxPersonalInformation.Controls.Add(Me.Label15)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxAdress)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxLastName)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxPhone)
        Me.GbxPersonalInformation.Controls.Add(Me.TbxEmail)
        Me.GbxPersonalInformation.Controls.Add(Me.Label13)
        Me.GbxPersonalInformation.Controls.Add(Me.Label12)
        Me.GbxPersonalInformation.Controls.Add(Me.Label14)
        Me.GbxPersonalInformation.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbxPersonalInformation.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.GbxPersonalInformation.Location = New System.Drawing.Point(47, 43)
        Me.GbxPersonalInformation.Name = "GbxPersonalInformation"
        Me.GbxPersonalInformation.Size = New System.Drawing.Size(361, 345)
        Me.GbxPersonalInformation.TabIndex = 29
        Me.GbxPersonalInformation.TabStop = False
        Me.GbxPersonalInformation.Text = "Personal Information"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 14)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Password"
        '
        'TbxPassword
        '
        Me.TbxPassword.Location = New System.Drawing.Point(114, 101)
        Me.TbxPassword.MaxLength = 20
        Me.TbxPassword.Name = "TbxPassword"
        Me.TbxPassword.Size = New System.Drawing.Size(200, 27)
        Me.TbxPassword.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(22, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 14)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Username"
        '
        'TbxUsername
        '
        Me.TbxUsername.Location = New System.Drawing.Point(114, 68)
        Me.TbxUsername.MaxLength = 20
        Me.TbxUsername.Name = "TbxUsername"
        Me.TbxUsername.Size = New System.Drawing.Size(200, 27)
        Me.TbxUsername.TabIndex = 1
        '
        'GbxTerms
        '
        Me.GbxTerms.Controls.Add(Me.CbxAgree)
        Me.GbxTerms.Controls.Add(Me.LstDisplay)
        Me.GbxTerms.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GbxTerms.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.GbxTerms.Location = New System.Drawing.Point(47, 43)
        Me.GbxTerms.Name = "GbxTerms"
        Me.GbxTerms.Size = New System.Drawing.Size(361, 345)
        Me.GbxTerms.TabIndex = 36
        Me.GbxTerms.TabStop = False
        Me.GbxTerms.Text = "Teams Of Use"
        '
        'CbxAgree
        '
        Me.CbxAgree.AutoSize = True
        Me.CbxAgree.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CbxAgree.Location = New System.Drawing.Point(25, 312)
        Me.CbxAgree.Name = "CbxAgree"
        Me.CbxAgree.Size = New System.Drawing.Size(171, 17)
        Me.CbxAgree.TabIndex = 20
        Me.CbxAgree.Text = "Agree to Terms and Conditions"
        Me.CbxAgree.UseVisualStyleBackColor = True
        '
        'LstDisplay
        '
        Me.LstDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LstDisplay.FormattingEnabled = True
        Me.LstDisplay.Items.AddRange(New Object() {"AGREEMENT TO TERMS", "", resources.GetString("LstDisplay.Items"), "", resources.GetString("LstDisplay.Items1"), "", resources.GetString("LstDisplay.Items2"), "", "We will alert you about any changes by updating the ""Last updated"" date of these " & _
                "Terms and Conditions, and you waive any right to receive specific notice of each" & _
                " such change.", "", resources.GetString("LstDisplay.Items3"), "", resources.GetString("LstDisplay.Items4"), "", resources.GetString("LstDisplay.Items5"), "", "These terms and conditions were generated by Termly’s Terms and Conditions Genera" & _
                "tor.", "", "Option 1: The Site is intended for users who are at least 18 years old. Persons u" & _
                "nder the age of 18 are not permitted to register for the Site.", "", resources.GetString("LstDisplay.Items6"), "", "INTELLECTUAL PROPERTY RIGHTS", "", resources.GetString("LstDisplay.Items7"), "", resources.GetString("LstDisplay.Items8"), "", resources.GetString("LstDisplay.Items9"), "", "USER REPRESENTATIONS", "", "By using the Site, you represent and warrant that:", "", resources.GetString("LstDisplay.Items10"), "", "(3) you have the legal capacity and you agree to comply with these Terms and Cond" & _
                "itions;", "", "[(4) you are not under the age of 13;]", "", "(5) not a minor in the jurisdiction in which you reside [, or if a minor, you hav" & _
                "e received parental permission to use the Site];", "", "(6) you will not access the Site through automated or non-human means, whether th" & _
                "rough a bot, script, or otherwise;", "", "(7) you will not use the Site for any illegal or unauthorized purpose;", "", "(8) your use of the Site will not violate any applicable law or regulation.", "", resources.GetString("LstDisplay.Items11"), "", "USER REGISTRATION", "", resources.GetString("LstDisplay.Items12"), "", "PROHIBITED ACTIVITIES", "", resources.GetString("LstDisplay.Items13"), "", "As a user of the Site, you agree not to:", "", "systematically retrieve data or other content from the Site to create or compile," & _
                " directly or indirectly, a collection, compilation, database, or directory witho" & _
                "ut written permission from us.", resources.GetString("LstDisplay.Items14"), "use a buying agent or purchasing agent to make purchases on the Site.", "use the Site to advertise or offer to sell goods and services.", resources.GetString("LstDisplay.Items15"), "engage in unauthorized framing of or linking to the Site.", "trick, defraud, or mislead us and other users, especially in any attempt to learn" & _
                " sensitive account information such as user passwords;", "make improper use of our support services or submit false reports of abuse or mis" & _
                "conduct.", "engage in any automated use of the system, such as using scripts to send comments" & _
                " or messages, or using any data mining, robots, or similar data gathering and ex" & _
                "traction tools.", "interfere with, disrupt, or create an undue burden on the Site or the networks or" & _
                " services connected to the Site.", "attempt to impersonate another user or person or use the username of another user" & _
                ".", "sell or otherwise transfer your profile.", "use any information obtained from the Site in order to harass, abuse, or harm ano" & _
                "ther person.", "use the Site as part of any effort to compete with us or otherwise use the Site a" & _
                "nd/or the Content for any revenue-generating endeavor or commercial enterprise.", "decipher, decompile, disassemble, or reverse engineer any of the software compris" & _
                "ing or in any way making up a part of the Site.", "attempt to bypass any measures of the Site designed to prevent or restrict access" & _
                " to the Site, or any portion of the Site.", "harass, annoy, intimidate, or threaten any of our employees or agents engaged in " & _
                "providing any portion of the Site to you.", "delete the copyright or other proprietary rights notice from any Content.", "copy or adapt the Site’s software, including but not limited to Flash, PHP, HTML," & _
                " JavaScript, or other code.", resources.GetString("LstDisplay.Items16"), resources.GetString("LstDisplay.Items17"), resources.GetString("LstDisplay.Items18"), "disparage, tarnish, or otherwise harm, in our opinion, us and/or the Site.", "use the Site in a manner inconsistent with any applicable laws or regulations.", "[other]", "USER GENERATED CONTRIBUTIONS", "", resources.GetString("LstDisplay.Items19"), "", resources.GetString("LstDisplay.Items20"), "", resources.GetString("LstDisplay.Items21"), resources.GetString("LstDisplay.Items22"), resources.GetString("LstDisplay.Items23"), "your Contributions are not false, inaccurate, or misleading.", "your Contributions are not unsolicited or unauthorized advertising, promotional m" & _
                "aterials, pyramid schemes, chain letters, spam, mass mailings, or other forms of" & _
                " solicitation.", "your Contributions are not obscene, lewd, lascivious, filthy, violent, harassing," & _
                " libelous, slanderous, or otherwise objectionable (as determined by us).", "your Contributions do not ridicule, mock, disparage, intimidate, or abuse anyone." & _
                "", "your Contributions do not advocate the violent overthrow of any government or inc" & _
                "ite, encourage, or threaten physical harm against another.", "your Contributions do not violate any applicable law, regulation, or rule.", "your Contributions do not violate the privacy or publicity rights of any third pa" & _
                "rty.", "your Contributions do not contain any material that solicits personal information" & _
                " from anyone under the age of 18 or exploits people under the age of 18 in a sex" & _
                "ual or violent manner.", "your Contributions do not violate any federal or state law concerning child porno" & _
                "graphy, or otherwise intended to protect the health or well-being of minors;", "your Contributions do not include any offensive comments that are connected to ra" & _
                "ce, national origin, gender, sexual preference, or physical handicap.", "your Contributions do not otherwise violate, or link to material that violates, a" & _
                "ny provision of these Terms and Conditions, or any applicable law or regulation." & _
                "", "Any use of the Site in violation of the foregoing violates these Terms and Condit" & _
                "ions and may result in, among other things, termination or suspension of your ri" & _
                "ghts to use the Site.", "", "CONTRIBUTION LICENSE", "", resources.GetString("LstDisplay.Items24"), "", resources.GetString("LstDisplay.Items25"), "", resources.GetString("LstDisplay.Items26"), "", resources.GetString("LstDisplay.Items27"), "", resources.GetString("LstDisplay.Items28"), "", "GUIDELINES FOR REVIEWS", "", "We may provide you areas on the Site to leave reviews or ratings. When posting a " & _
                "review, you must comply with the following criteria:", "", "(1) you should have firsthand experience with the person/entity being reviewed;", "", "(2) your reviews should not contain offensive profanity, or abusive, racist, offe" & _
                "nsive, or hate language;", "", "(3) your reviews should not contain discriminatory references based on religion, " & _
                "race, gender, national origin, age, marital status, sexual orientation, or disab" & _
                "ility;", "", "(4) your reviews should not contain references to illegal activity;", "", "(5) you should not be affiliated with competitors if posting negative reviews;", "", "(6) you should not make any conclusions as to the legality of conduct;", "", "(7) you may not post any false or misleading statements;", "", "(8) you may not organize a campaign encouraging others to post reviews, whether p" & _
                "ositive or negative.", "", resources.GetString("LstDisplay.Items29"), "", resources.GetString("LstDisplay.Items30"), "", "MOBILE APPLICATION LICENSE", "", "Use License", "", resources.GetString("LstDisplay.Items31"), "", "You shall not:", "", "(1) decompile, reverse engineer, disassemble, attempt to derive the source code o" & _
                "f, or decrypt the application;", "", "(2) make any modification, adaptation, improvement, enhancement, translation, or " & _
                "derivative work from the application;", "", "(3) violate any applicable laws, rules, or regulations in connection with your ac" & _
                "cess or use of the application;", "", "(4) remove, alter, or obscure any proprietary notice (including any notice of cop" & _
                "yright or trademark) posted by us or the licensors of the application;", "", "(5) use the application for any revenue generating endeavor, commercial enterpris" & _
                "e, or other purpose for which it is not designed or intended;", "", "(6) make the application available over a network or other environment permitting" & _
                " access or use by multiple devices or users at the same time;", "", "(7) use the application for creating a product, service, or software that is, dir" & _
                "ectly or indirectly, competitive with or in any way a substitute for the applica" & _
                "tion;", "", "(8) use the application to send automated queries to any website or to send any u" & _
                "nsolicited commercial e-mail;", "", resources.GetString("LstDisplay.Items32"), "", "Apple and Android Devices", "", "The following terms apply when you use a mobile application obtained from either " & _
                "the Apple Store or Google Play (each an ""App Distributor"") to access the Site:", "", resources.GetString("LstDisplay.Items33"), "", resources.GetString("LstDisplay.Items34"), "", resources.GetString("LstDisplay.Items35"), "", resources.GetString("LstDisplay.Items36"), "", resources.GetString("LstDisplay.Items37"), "", resources.GetString("LstDisplay.Items38"), "", "SOCIAL MEDIA", "", resources.GetString("LstDisplay.Items39"), "", resources.GetString("LstDisplay.Items40"), "", resources.GetString("LstDisplay.Items41"), "", resources.GetString("LstDisplay.Items42"), "", resources.GetString("LstDisplay.Items43"), "", "PLEASE NOTE THAT YOUR RELATIONSHIP WITH THE THIRD-PARTY SERVICE PROVIDERS ASSOCIA" & _
                "TED WITH YOUR THIRD-PARTY ACCOUNTS IS GOVERNED SOLELY BY YOUR AGREEMENT(S) WITH " & _
                "SUCH THIRD-PARTY SERVICE PROVIDERS.", "", resources.GetString("LstDisplay.Items44"), "", resources.GetString("LstDisplay.Items45"), "", resources.GetString("LstDisplay.Items46"), "", "SUBMISSIONS", "", resources.GetString("LstDisplay.Items47"), "", resources.GetString("LstDisplay.Items48"), "", "THIRD-PARTY WEBSITES AND CONTENT", "", resources.GetString("LstDisplay.Items49"), "", resources.GetString("LstDisplay.Items50"), "", resources.GetString("LstDisplay.Items51"), "", resources.GetString("LstDisplay.Items52"), "", resources.GetString("LstDisplay.Items53"), "", "ADVERTISERS", "", resources.GetString("LstDisplay.Items54"), "", resources.GetString("LstDisplay.Items55"), "", resources.GetString("LstDisplay.Items56"), "", "SITE MANAGEMENT", "", "We reserve the right, but not the obligation, to:", "", "(1) monitor the Site for violations of these Terms and Conditions;", "", resources.GetString("LstDisplay.Items57"), "", resources.GetString("LstDisplay.Items58"), "", resources.GetString("LstDisplay.Items59"), "", "(5) otherwise manage the Site in a manner designed to protect our rights and prop" & _
                "erty and to facilitate the proper functioning of the Site.", "", "PRIVACY POLICY", "", resources.GetString("LstDisplay.Items60"), "", resources.GetString("LstDisplay.Items61"), "", resources.GetString("LstDisplay.Items62"), "", "DIGITAL MILLENNIUM COPYRIGHT ACT (DMCA) NOTICE AND POLICY", "", "Notifications", "", resources.GetString("LstDisplay.Items63"), "", resources.GetString("LstDisplay.Items64"), "", "All Notifications should meet the requirements of DMCA 17 U.S.C. § 512(c)(3) and " & _
                "include the following information:", "", "(1) A physical or electronic signature of a person authorized to act on behalf of" & _
                " the owner of an exclusive right that is allegedly infringed;", "", resources.GetString("LstDisplay.Items65"), "", resources.GetString("LstDisplay.Items66"), "", resources.GetString("LstDisplay.Items67"), "", "(5) a statement that the complaining party has a good faith belief that use of th" & _
                "e material in the manner complained of is not authorized by the copyright owner," & _
                " its agent, or the law;", "", resources.GetString("LstDisplay.Items68"), "", "Counter Notification", "", resources.GetString("LstDisplay.Items69"), "", "To be an effective Counter Notification u"})
        Me.LstDisplay.Location = New System.Drawing.Point(10, 29)
        Me.LstDisplay.Name = "LstDisplay"
        Me.LstDisplay.Size = New System.Drawing.Size(339, 264)
        Me.LstDisplay.TabIndex = 19
        '
        'BtnBack
        '
        Me.BtnBack.Location = New System.Drawing.Point(223, 410)
        Me.BtnBack.Name = "BtnBack"
        Me.BtnBack.Size = New System.Drawing.Size(75, 23)
        Me.BtnBack.TabIndex = 10
        Me.BtnBack.Text = "Back"
        Me.BtnBack.UseVisualStyleBackColor = True
        Me.BtnBack.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe Marker", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label4.Location = New System.Drawing.Point(197, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 31)
        Me.Label4.TabIndex = 33
        '
        'Register
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(455, 449)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.BtnBack)
        Me.Controls.Add(Me.BtnNext)
        Me.Controls.Add(Me.BtnReturn)
        Me.Controls.Add(Me.GbxTerms)
        Me.Controls.Add(Me.GbxPersonalInformation)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Register"
        Me.Text = " Video Collection Library"
        Me.GbxPersonalInformation.ResumeLayout(False)
        Me.GbxPersonalInformation.PerformLayout()
        Me.GbxTerms.ResumeLayout(False)
        Me.GbxTerms.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TbxFirstName As System.Windows.Forms.TextBox
    Friend WithEvents BtnReturn As System.Windows.Forms.Button
    Friend WithEvents BtnNext As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TbxEmail As System.Windows.Forms.TextBox
    Friend WithEvents TbxPhone As System.Windows.Forms.TextBox
    Friend WithEvents TbxLastName As System.Windows.Forms.TextBox
    Friend WithEvents TbxAdress As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DtpDob As System.Windows.Forms.DateTimePicker
    Friend WithEvents GbxPersonalInformation As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TbxPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TbxUsername As System.Windows.Forms.TextBox
    Friend WithEvents BtnBack As System.Windows.Forms.Button
    Friend WithEvents GbxTerms As System.Windows.Forms.GroupBox
    Friend WithEvents CbxAgree As System.Windows.Forms.CheckBox
    Friend WithEvents LstDisplay As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
