﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddVideo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AddVideo))
        Me.BtnAddVideo = New System.Windows.Forms.Button()
        Me.TbxTitle = New System.Windows.Forms.TextBox()
        Me.TbxReleaseDate = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.BtnSearch = New System.Windows.Forms.PictureBox()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnExplore = New System.Windows.Forms.Button()
        Me.BtnHome = New System.Windows.Forms.Button()
        Me.TbxSearch = New System.Windows.Forms.TextBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PbxSignOut = New System.Windows.Forms.PictureBox()
        Me.PbxExit = New System.Windows.Forms.PictureBox()
        Me.PbxAdd = New System.Windows.Forms.PictureBox()
        Me.PbxExplore = New System.Windows.Forms.PictureBox()
        Me.PbxHome = New System.Windows.Forms.PictureBox()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape3 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.CbxGenre = New System.Windows.Forms.ComboBox()
        Me.TbxGenre = New System.Windows.Forms.TextBox()
        Me.BtnAddGenre = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CbxClassification = New System.Windows.Forms.ComboBox()
        Me.PbxR = New System.Windows.Forms.PictureBox()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.PbxMA = New System.Windows.Forms.PictureBox()
        Me.PbxM = New System.Windows.Forms.PictureBox()
        Me.PbxG = New System.Windows.Forms.PictureBox()
        Me.PbxPG = New System.Windows.Forms.PictureBox()
        Me.PbxCTC = New System.Windows.Forms.PictureBox()
        Me.BtnEdit = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PbxEdit = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.BtnSearch, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxSignOut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxExit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxAdd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxExplore, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxHome, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxMA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxPG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxCTC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PbxEdit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BtnAddVideo
        '
        Me.BtnAddVideo.Location = New System.Drawing.Point(780, 542)
        Me.BtnAddVideo.Name = "BtnAddVideo"
        Me.BtnAddVideo.Size = New System.Drawing.Size(94, 36)
        Me.BtnAddVideo.TabIndex = 4
        Me.BtnAddVideo.Text = "Add New Video"
        Me.BtnAddVideo.UseVisualStyleBackColor = True
        '
        'TbxTitle
        '
        Me.TbxTitle.Location = New System.Drawing.Point(515, 190)
        Me.TbxTitle.MaxLength = 30
        Me.TbxTitle.Name = "TbxTitle"
        Me.TbxTitle.Size = New System.Drawing.Size(160, 20)
        Me.TbxTitle.TabIndex = 1
        '
        'TbxReleaseDate
        '
        Me.TbxReleaseDate.Location = New System.Drawing.Point(515, 351)
        Me.TbxReleaseDate.MaxLength = 4
        Me.TbxReleaseDate.Name = "TbxReleaseDate"
        Me.TbxReleaseDate.Size = New System.Drawing.Size(160, 20)
        Me.TbxReleaseDate.TabIndex = 3
        Me.TbxReleaseDate.Text = "YYYY"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe Marker", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label3.Location = New System.Drawing.Point(346, 38)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(281, 74)
        Me.Label3.TabIndex = 144
        Me.Label3.Text = "Add Video"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label6.Location = New System.Drawing.Point(30, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 34)
        Me.Label6.TabIndex = 143
        Me.Label6.Text = "Menu"
        '
        'BtnSearch
        '
        Me.BtnSearch.ErrorImage = CType(resources.GetObject("BtnSearch.ErrorImage"), System.Drawing.Image)
        Me.BtnSearch.Image = CType(resources.GetObject("BtnSearch.Image"), System.Drawing.Image)
        Me.BtnSearch.Location = New System.Drawing.Point(853, 22)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.Size = New System.Drawing.Size(30, 30)
        Me.BtnSearch.TabIndex = 142
        Me.BtnSearch.TabStop = False
        '
        'BtnLogout
        '
        Me.BtnLogout.AutoSize = True
        Me.BtnLogout.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.BtnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnLogout.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.BtnLogout.FlatAppearance.BorderSize = 0
        Me.BtnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLogout.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLogout.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnLogout.Location = New System.Drawing.Point(62, 473)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(120, 44)
        Me.BtnLogout.TabIndex = 137
        Me.BtnLogout.Text = "Sign-out"
        Me.BtnLogout.UseVisualStyleBackColor = False
        '
        'BtnExit
        '
        Me.BtnExit.AutoSize = True
        Me.BtnExit.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.BtnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnExit.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.BtnExit.FlatAppearance.BorderSize = 0
        Me.BtnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnExit.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExit.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnExit.Location = New System.Drawing.Point(62, 542)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(100, 44)
        Me.BtnExit.TabIndex = 136
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = False
        '
        'BtnAdd
        '
        Me.BtnAdd.AutoSize = True
        Me.BtnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.BtnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnAdd.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.BtnAdd.FlatAppearance.BorderSize = 0
        Me.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAdd.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAdd.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnAdd.Location = New System.Drawing.Point(62, 190)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(69, 44)
        Me.BtnAdd.TabIndex = 131
        Me.BtnAdd.Text = "Add"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'BtnExplore
        '
        Me.BtnExplore.AutoSize = True
        Me.BtnExplore.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.BtnExplore.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnExplore.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.BtnExplore.FlatAppearance.BorderSize = 0
        Me.BtnExplore.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnExplore.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnExplore.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnExplore.Location = New System.Drawing.Point(62, 131)
        Me.BtnExplore.Name = "BtnExplore"
        Me.BtnExplore.Size = New System.Drawing.Size(109, 44)
        Me.BtnExplore.TabIndex = 130
        Me.BtnExplore.Text = "Explore"
        Me.BtnExplore.UseVisualStyleBackColor = False
        '
        'BtnHome
        '
        Me.BtnHome.AutoSize = True
        Me.BtnHome.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.BtnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnHome.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.BtnHome.FlatAppearance.BorderSize = 0
        Me.BtnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHome.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHome.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnHome.Location = New System.Drawing.Point(62, 68)
        Me.BtnHome.Name = "BtnHome"
        Me.BtnHome.Size = New System.Drawing.Size(91, 44)
        Me.BtnHome.TabIndex = 128
        Me.BtnHome.Text = "Home"
        Me.BtnHome.UseVisualStyleBackColor = False
        '
        'TbxSearch
        '
        Me.TbxSearch.Font = New System.Drawing.Font("Segoe Marker", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TbxSearch.Location = New System.Drawing.Point(687, 22)
        Me.TbxSearch.Name = "TbxSearch"
        Me.TbxSearch.Size = New System.Drawing.Size(160, 30)
        Me.TbxSearch.TabIndex = 127
        '
        'PictureBox26
        '
        Me.PictureBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox26.Image = CType(resources.GetObject("PictureBox26.Image"), System.Drawing.Image)
        Me.PictureBox26.Location = New System.Drawing.Point(220, 16)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox26.TabIndex = 145
        Me.PictureBox26.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe Marker", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label4.Location = New System.Drawing.Point(262, 340)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(212, 31)
        Me.Label4.TabIndex = 149
        Me.Label4.Text = "Year of Release Date"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe Marker", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label5.Location = New System.Drawing.Point(262, 251)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 31)
        Me.Label5.TabIndex = 150
        Me.Label5.Text = "Genre"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe Marker", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Location = New System.Drawing.Point(262, 185)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 31)
        Me.Label7.TabIndex = 151
        Me.Label7.Text = "Title"
        '
        'PbxSignOut
        '
        Me.PbxSignOut.Image = CType(resources.GetObject("PbxSignOut.Image"), System.Drawing.Image)
        Me.PbxSignOut.Location = New System.Drawing.Point(12, 476)
        Me.PbxSignOut.Name = "PbxSignOut"
        Me.PbxSignOut.Size = New System.Drawing.Size(44, 44)
        Me.PbxSignOut.TabIndex = 159
        Me.PbxSignOut.TabStop = False
        '
        'PbxExit
        '
        Me.PbxExit.Image = CType(resources.GetObject("PbxExit.Image"), System.Drawing.Image)
        Me.PbxExit.Location = New System.Drawing.Point(12, 542)
        Me.PbxExit.Name = "PbxExit"
        Me.PbxExit.Size = New System.Drawing.Size(44, 44)
        Me.PbxExit.TabIndex = 158
        Me.PbxExit.TabStop = False
        '
        'PbxAdd
        '
        Me.PbxAdd.Image = CType(resources.GetObject("PbxAdd.Image"), System.Drawing.Image)
        Me.PbxAdd.Location = New System.Drawing.Point(12, 190)
        Me.PbxAdd.Name = "PbxAdd"
        Me.PbxAdd.Size = New System.Drawing.Size(44, 44)
        Me.PbxAdd.TabIndex = 157
        Me.PbxAdd.TabStop = False
        '
        'PbxExplore
        '
        Me.PbxExplore.Image = CType(resources.GetObject("PbxExplore.Image"), System.Drawing.Image)
        Me.PbxExplore.Location = New System.Drawing.Point(12, 131)
        Me.PbxExplore.Name = "PbxExplore"
        Me.PbxExplore.Size = New System.Drawing.Size(44, 44)
        Me.PbxExplore.TabIndex = 155
        Me.PbxExplore.TabStop = False
        '
        'PbxHome
        '
        Me.PbxHome.Image = CType(resources.GetObject("PbxHome.Image"), System.Drawing.Image)
        Me.PbxHome.Location = New System.Drawing.Point(12, 68)
        Me.PbxHome.Name = "PbxHome"
        Me.PbxHome.Size = New System.Drawing.Size(44, 44)
        Me.PbxHome.TabIndex = 154
        Me.PbxHome.TabStop = False
        '
        'LineShape1
        '
        Me.LineShape1.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 206
        Me.LineShape1.X2 = 206
        Me.LineShape1.Y1 = 28
        Me.LineShape1.Y2 = 580
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape3, Me.LineShape2, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(912, 604)
        Me.ShapeContainer1.TabIndex = 161
        Me.ShapeContainer1.TabStop = False
        '
        'LineShape3
        '
        Me.LineShape3.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.LineShape3.Name = "LineShape3"
        Me.LineShape3.X1 = 215
        Me.LineShape3.X2 = 900
        Me.LineShape3.Y1 = 130
        Me.LineShape3.Y2 = 130
        '
        'LineShape2
        '
        Me.LineShape2.BorderColor = System.Drawing.SystemColors.ButtonFace
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 195
        Me.LineShape2.X2 = 19
        Me.LineShape2.Y1 = 55
        Me.LineShape2.Y2 = 55
        '
        'CbxGenre
        '
        Me.CbxGenre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CbxGenre.FormattingEnabled = True
        Me.CbxGenre.Items.AddRange(New Object() {"Action", "Adventure", "Animation", "Comedy", "Crime", "Documentary", "Drama", "Experimental", "Family", "Fantasy", "Historical", "Horror", "Live-action", "Mystery", "Philosophical", "Political", "Romance", "Science Fiction", "Superhero", "Thriller", "War", "Western"})
        Me.CbxGenre.Location = New System.Drawing.Point(743, 262)
        Me.CbxGenre.Name = "CbxGenre"
        Me.CbxGenre.Size = New System.Drawing.Size(121, 21)
        Me.CbxGenre.TabIndex = 162
        '
        'TbxGenre
        '
        Me.TbxGenre.Location = New System.Drawing.Point(515, 263)
        Me.TbxGenre.MaxLength = 30
        Me.TbxGenre.Multiline = True
        Me.TbxGenre.Name = "TbxGenre"
        Me.TbxGenre.Size = New System.Drawing.Size(160, 40)
        Me.TbxGenre.TabIndex = 163
        Me.TbxGenre.Text = "XXX, YYY, ZZZ"
        '
        'BtnAddGenre
        '
        Me.BtnAddGenre.Location = New System.Drawing.Point(789, 289)
        Me.BtnAddGenre.Name = "BtnAddGenre"
        Me.BtnAddGenre.Size = New System.Drawing.Size(75, 23)
        Me.BtnAddGenre.TabIndex = 164
        Me.BtnAddGenre.Text = "Add Genre"
        Me.BtnAddGenre.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe Marker", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(262, 414)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(205, 31)
        Me.Label1.TabIndex = 165
        Me.Label1.Text = "Movie Classification"
        '
        'CbxClassification
        '
        Me.CbxClassification.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CbxClassification.FormattingEnabled = True
        Me.CbxClassification.Items.AddRange(New Object() {"G", "PG", "M", "MA 15+", "R 18+"})
        Me.CbxClassification.Location = New System.Drawing.Point(515, 425)
        Me.CbxClassification.Name = "CbxClassification"
        Me.CbxClassification.Size = New System.Drawing.Size(88, 21)
        Me.CbxClassification.TabIndex = 166
        '
        'PbxR
        '
        Me.PbxR.Image = CType(resources.GetObject("PbxR.Image"), System.Drawing.Image)
        Me.PbxR.Location = New System.Drawing.Point(657, 414)
        Me.PbxR.Name = "PbxR"
        Me.PbxR.Size = New System.Drawing.Size(90, 90)
        Me.PbxR.TabIndex = 167
        Me.PbxR.TabStop = False
        Me.PbxR.Visible = False
        '
        'BtnClear
        '
        Me.BtnClear.Location = New System.Drawing.Point(680, 542)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(94, 36)
        Me.BtnClear.TabIndex = 168
        Me.BtnClear.Text = "Clear"
        Me.BtnClear.UseVisualStyleBackColor = True
        '
        'PbxMA
        '
        Me.PbxMA.Image = CType(resources.GetObject("PbxMA.Image"), System.Drawing.Image)
        Me.PbxMA.Location = New System.Drawing.Point(657, 414)
        Me.PbxMA.Name = "PbxMA"
        Me.PbxMA.Size = New System.Drawing.Size(90, 90)
        Me.PbxMA.TabIndex = 169
        Me.PbxMA.TabStop = False
        Me.PbxMA.Visible = False
        '
        'PbxM
        '
        Me.PbxM.Image = CType(resources.GetObject("PbxM.Image"), System.Drawing.Image)
        Me.PbxM.Location = New System.Drawing.Point(657, 414)
        Me.PbxM.Name = "PbxM"
        Me.PbxM.Size = New System.Drawing.Size(90, 90)
        Me.PbxM.TabIndex = 170
        Me.PbxM.TabStop = False
        Me.PbxM.Visible = False
        '
        'PbxG
        '
        Me.PbxG.Image = CType(resources.GetObject("PbxG.Image"), System.Drawing.Image)
        Me.PbxG.Location = New System.Drawing.Point(657, 414)
        Me.PbxG.Name = "PbxG"
        Me.PbxG.Size = New System.Drawing.Size(90, 90)
        Me.PbxG.TabIndex = 171
        Me.PbxG.TabStop = False
        Me.PbxG.Visible = False
        '
        'PbxPG
        '
        Me.PbxPG.Image = CType(resources.GetObject("PbxPG.Image"), System.Drawing.Image)
        Me.PbxPG.Location = New System.Drawing.Point(657, 414)
        Me.PbxPG.Name = "PbxPG"
        Me.PbxPG.Size = New System.Drawing.Size(90, 90)
        Me.PbxPG.TabIndex = 172
        Me.PbxPG.TabStop = False
        Me.PbxPG.Visible = False
        '
        'PbxCTC
        '
        Me.PbxCTC.Image = CType(resources.GetObject("PbxCTC.Image"), System.Drawing.Image)
        Me.PbxCTC.Location = New System.Drawing.Point(657, 414)
        Me.PbxCTC.Name = "PbxCTC"
        Me.PbxCTC.Size = New System.Drawing.Size(90, 90)
        Me.PbxCTC.TabIndex = 173
        Me.PbxCTC.TabStop = False
        '
        'BtnEdit
        '
        Me.BtnEdit.AutoSize = True
        Me.BtnEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.BtnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnEdit.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.BtnEdit.FlatAppearance.BorderSize = 0
        Me.BtnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEdit.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnEdit.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnEdit.Location = New System.Drawing.Point(62, 256)
        Me.BtnEdit.Name = "BtnEdit"
        Me.BtnEdit.Size = New System.Drawing.Size(69, 44)
        Me.BtnEdit.TabIndex = 175
        Me.BtnEdit.Text = "Edit"
        Me.BtnEdit.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.AutoSize = True
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe Marker", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Button1.Location = New System.Drawing.Point(62, 319)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(115, 44)
        Me.Button1.TabIndex = 174
        Me.Button1.Text = "Settings"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PbxEdit
        '
        Me.PbxEdit.Image = CType(resources.GetObject("PbxEdit.Image"), System.Drawing.Image)
        Me.PbxEdit.Location = New System.Drawing.Point(12, 256)
        Me.PbxEdit.Name = "PbxEdit"
        Me.PbxEdit.Size = New System.Drawing.Size(44, 44)
        Me.PbxEdit.TabIndex = 177
        Me.PbxEdit.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 319)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(44, 44)
        Me.PictureBox1.TabIndex = 176
        Me.PictureBox1.TabStop = False
        '
        'AddVideo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(10, Byte), Integer), CType(CType(10, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(912, 604)
        Me.Controls.Add(Me.BtnEdit)
        Me.Controls.Add(Me.PbxCTC)
        Me.Controls.Add(Me.BtnClear)
        Me.Controls.Add(Me.CbxClassification)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnAddGenre)
        Me.Controls.Add(Me.TbxGenre)
        Me.Controls.Add(Me.CbxGenre)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.BtnSearch)
        Me.Controls.Add(Me.BtnLogout)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.BtnAdd)
        Me.Controls.Add(Me.BtnExplore)
        Me.Controls.Add(Me.BtnHome)
        Me.Controls.Add(Me.TbxSearch)
        Me.Controls.Add(Me.PictureBox26)
        Me.Controls.Add(Me.TbxReleaseDate)
        Me.Controls.Add(Me.TbxTitle)
        Me.Controls.Add(Me.BtnAddVideo)
        Me.Controls.Add(Me.PbxSignOut)
        Me.Controls.Add(Me.PbxExit)
        Me.Controls.Add(Me.PbxAdd)
        Me.Controls.Add(Me.PbxExplore)
        Me.Controls.Add(Me.PbxHome)
        Me.Controls.Add(Me.PbxPG)
        Me.Controls.Add(Me.PbxG)
        Me.Controls.Add(Me.PbxM)
        Me.Controls.Add(Me.PbxMA)
        Me.Controls.Add(Me.PbxR)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PbxEdit)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "AddVideo"
        Me.Text = " Video Collection Library"
        CType(Me.BtnSearch, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxSignOut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxExit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxAdd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxExplore, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxHome, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxMA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxPG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxCTC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PbxEdit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnAddVideo As System.Windows.Forms.Button
    Friend WithEvents TbxTitle As System.Windows.Forms.TextBox
    Friend WithEvents TbxReleaseDate As System.Windows.Forms.TextBox
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents BtnSearch As System.Windows.Forms.PictureBox
    Friend WithEvents BtnLogout As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents BtnAdd As System.Windows.Forms.Button
    Friend WithEvents BtnExplore As System.Windows.Forms.Button
    Friend WithEvents BtnHome As System.Windows.Forms.Button
    Friend WithEvents TbxSearch As System.Windows.Forms.TextBox
    Public WithEvents PictureBox26 As System.Windows.Forms.PictureBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PbxSignOut As System.Windows.Forms.PictureBox
    Friend WithEvents PbxExit As System.Windows.Forms.PictureBox
    Friend WithEvents PbxAdd As System.Windows.Forms.PictureBox
    Friend WithEvents PbxExplore As System.Windows.Forms.PictureBox
    Friend WithEvents PbxHome As System.Windows.Forms.PictureBox
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents LineShape3 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents CbxGenre As System.Windows.Forms.ComboBox
    Friend WithEvents TbxGenre As System.Windows.Forms.TextBox
    Friend WithEvents BtnAddGenre As System.Windows.Forms.Button
    Public WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CbxClassification As System.Windows.Forms.ComboBox
    Friend WithEvents PbxR As System.Windows.Forms.PictureBox
    Friend WithEvents BtnClear As System.Windows.Forms.Button
    Friend WithEvents PbxMA As System.Windows.Forms.PictureBox
    Friend WithEvents PbxM As System.Windows.Forms.PictureBox
    Friend WithEvents PbxG As System.Windows.Forms.PictureBox
    Friend WithEvents PbxPG As System.Windows.Forms.PictureBox
    Friend WithEvents PbxCTC As System.Windows.Forms.PictureBox
    Friend WithEvents BtnEdit As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PbxEdit As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
