﻿Imports System.IO

Public Class AddVideo

#Region "Dims"
    Dim verificationCheck As Boolean = True
    Dim counterReleaseDate = 0
    Dim counterGenre = 0
#End Region

#Region "Main Code"
#Region "Add Video"
    Private Sub BtnAddVideo_Click(sender As Object, e As EventArgs) Handles BtnAddVideo.Click
        Dim VideoListFile As Object = (Login.UsersFile)
        Dim srdVideoList As IO.StreamWriter

        If Not File.Exists(VideoListFile) Then
            MsgBox("Connection Failed")
            Exit Sub
        End If

        srdVideoList = New IO.StreamWriter(Login.UsersFile, True)

        Validation()

        If verificationCheck = True Then
            'write in the variable into the file
            srdVideoList.WriteLine(TbxTitle.Text)
            srdVideoList.WriteLine(TbxGenre.Text)
            srdVideoList.WriteLine(TbxReleaseDate.Text)
            srdVideoList.WriteLine(CbxClassification.Text)

            srdVideoList.Close()

            Dim ConfirmMsg As Integer
            ConfirmMsg = MessageBox.Show("Confirm Video Information", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            If ConfirmMsg = vbYes Then
                Clear()
                MsgBox("Your Video Was Added")
            End If

        Else
            Exit Sub
        End If

    End Sub
#End Region

#Region "Genre"
    Private Sub BtnAddGenre_Click(sender As Object, e As EventArgs) Handles BtnAddGenre.Click
        Select Case CbxGenre.SelectedIndex
            'all genres
            Case 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
                If TbxGenre.Text = "" Or TbxGenre.Text = "XXX, YYY, ZZZ" Then
                    TbxGenre.Text = CbxGenre.Text
                    counterGenre = counterGenre + 1
                Else
                    TbxGenre.Text = (TbxGenre.Text & ", " & CbxGenre.Text)
                End If
        End Select
    End Sub
#End Region

#Region "Classifications"
    Private Sub CbxRating_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CbxClassification.SelectedIndexChanged
        Select Case CbxClassification.SelectedIndex
            'Classification G
            Case 0
                PbxG.Visible = True
                PbxPG.Visible = False
                PbxM.Visible = False
                PbxMA.Visible = False
                PbxR.Visible = False
                PbxCTC.Visible = False

                'Classification PG
            Case 1
                PbxG.Visible = False
                PbxPG.Visible = True
                PbxM.Visible = False
                PbxMA.Visible = False
                PbxR.Visible = False
                PbxCTC.Visible = False

                'Classification M
            Case 2
                PbxG.Visible = False
                PbxPG.Visible = False
                PbxM.Visible = True
                PbxMA.Visible = False
                PbxR.Visible = False
                PbxCTC.Visible = False

                'Classification MA
            Case 3
                PbxG.Visible = False
                PbxPG.Visible = False
                PbxM.Visible = False
                PbxMA.Visible = True
                PbxR.Visible = False
                PbxCTC.Visible = False

                'Classification R
            Case 4
                PbxG.Visible = False
                PbxPG.Visible = False
                PbxM.Visible = False
                PbxMA.Visible = False
                PbxR.Visible = True
                PbxCTC.Visible = False
        End Select
    End Sub
#End Region

#End Region

#Region "Validation"
    Sub Validation()
        If TbxTitle.Text = "" Then
            verificationCheck = False
            MsgBox("Please Add The Title")
            Exit Sub
        ElseIf TbxGenre.Text = "" Or TbxGenre.Text = "XXX, YYY, ZZZ" Then
            verificationCheck = False
            MsgBox("Please Add The Genre")
            Exit Sub
        ElseIf IsNumeric(TbxGenre.Text) Then
            verificationCheck = False
            MsgBox("Please Ensure Genre's Do Not Include Numbers")
            Exit Sub
        ElseIf TbxReleaseDate.Text = "" Then
            verificationCheck = False
            MsgBox("Please Add The Release Date")
            Exit Sub
        ElseIf TbxReleaseDate.Text.Length < 4 Then
            verificationCheck = False
            MsgBox("Please Add The Full Year")
            Exit Sub
        ElseIf TbxReleaseDate.Text > Year(Today) Then
            verificationCheck = False
            MsgBox("The Movie Cannot Be Release in The Future")
            Exit Sub
        ElseIf CbxClassification.SelectedIndex = -1 Then
            verificationCheck = False
            MsgBox("Please Select The Movie Classification")
            Exit Sub
        End If
    End Sub
#End Region

#Region "Misc"
    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        Dim ConfirmMsg As Integer
        ConfirmMsg = MessageBox.Show("Confirm Clear All", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ConfirmMsg = vbYes Then
            Clear()
        End If
    End Sub
    Sub Clear()
        'clear all text boxes
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = Nothing
            End If
        Next
        CbxClassification.SelectedIndex = -1
        CbxGenre.SelectedIndex = -1
        TbxGenre.Text = "XXX, YYY, ZZZ"
        TbxReleaseDate.Text = "YYYY"
        counterGenre = 0
        counterReleaseDate = 0

        'reset the picture Boxes
        PbxG.Visible = False
        PbxPG.Visible = False
        PbxM.Visible = False
        PbxMA.Visible = False
        PbxR.Visible = False
        PbxCTC.Visible = True
    End Sub

    'this allows for suggested formatting for the text on the form
    Private Sub TbxReleaseDate_MouseClick(sender As Object, e As MouseEventArgs) Handles TbxReleaseDate.MouseClick
        If counterReleaseDate = 0 Then
            TbxReleaseDate.Text = ""
            counterReleaseDate += 1
        End If
    End Sub
    'this allows for suggested formatting for the text on the form
    Private Sub TbxGenre_MouseClick(sender As Object, e As MouseEventArgs) Handles TbxGenre.MouseClick
        If counterGenre = 0 Then
            TbxGenre.Text = ""
            counterGenre += 1
        End If
    End Sub
#End Region

#Region "Menu Buttons"
    'Menu Buttons
    Private Sub BtnHome_Click(sender As Object, e As EventArgs) Handles BtnHome.Click
        Me.Hide()
        Home.Show()
        Home.Refresh()
    End Sub
    Private Sub BtnExplore_Click(sender As Object, e As EventArgs) Handles BtnExplore.Click
        Me.Hide()
        Explore.Show()
        Explore.Refresh()
    End Sub
    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        Me.Hide()
        Me.Show()
        Me.Refresh()
    End Sub
    Private Sub BtnSettings_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Settings.Show()
        Settings.Refresh()
    End Sub
    Private Sub BtnReports_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Edit.Show()
        Edit.Refresh()
    End Sub
    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        Dim ConfirmMsg As Integer
        ConfirmMsg = MessageBox.Show("Are you sure you want to Sign-Out?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ConfirmMsg = vbYes Then
            MsgBox("Bye For Now")
            Me.Hide()
            Login.Show()
            Login.Refresh()
        End If
    End Sub
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Dim ConfirmMsg As Integer
        ConfirmMsg = MessageBox.Show("Are you sure you want to Exit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ConfirmMsg = vbYes Then
            MsgBox("Bye For Now")
            End
        End If
    End Sub

    'Menu picture boxes
    Private Sub PbxExit_Click(sender As Object, e As EventArgs) Handles PbxExit.Click
        Dim ConfirmMsg As Integer
        ConfirmMsg = MessageBox.Show("Are you sure you want to Exit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ConfirmMsg = vbYes Then
            MsgBox("Bye For Now")
            End
        End If
    End Sub
    Private Sub PbxHome_Click(sender As Object, e As EventArgs) Handles PbxHome.Click
        Me.Hide()
        Home.Show()
        Home.Refresh()
    End Sub
    Private Sub PbxReport_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Edit.Show()
        Edit.Refresh()
    End Sub
    Private Sub PbxSettings_Click(sender As Object, e As EventArgs)
        Me.Hide()
        Settings.Show()
        Settings.Refresh()
    End Sub
    Private Sub PbxAdd_Click(sender As Object, e As EventArgs) Handles PbxAdd.Click
        Me.Hide()
        Me.Show()
        Me.Refresh()
    End Sub
    Private Sub PbxExplore_Click(sender As Object, e As EventArgs) Handles PbxExplore.Click
        Me.Hide()
        Explore.Show()
        Explore.Refresh()
    End Sub
    Private Sub PbxSignOut_Click(sender As Object, e As EventArgs) Handles PbxSignOut.Click
        Dim ConfirmMsg As Integer
        ConfirmMsg = MessageBox.Show("Are you sure you want to Sign-Out?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ConfirmMsg = vbYes Then
            MsgBox("Bye For Now")
            Me.Hide()
            Login.Show()
            Login.Refresh()
        End If
    End Sub

    'Other Methods to return to Home
    Private Sub PbxLogo_Click(sender As Object, e As EventArgs)
        Home.Show()
        Me.Hide()
        Home.Refresh()
    End Sub
    Private Sub LblMenu_Click(sender As Object, e As EventArgs)
        Home.Show()
        Me.Hide()
        Home.Refresh()
    End Sub

    'search button
    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        Me.Hide()
        Search.Show()
        Search.Refresh()
    End Sub
#End Region

End Class